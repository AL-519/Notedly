# JavaScript Everywhere API Solutions

> The completed API code example for JavaScript Everywhere by Adam Scott, published by O'Reilly Media

This directory contains the final API example found in the book. For the starter project, visit the `/src` directory and for chapter by chapter solutions, visit `/solutions`.


## Getting Help

The best place to get help is our Spectrum channel, [spectrum.chat/jseverywhere](https://spectrum.chat/jseverywhere).
