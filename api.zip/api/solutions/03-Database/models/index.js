const Note = require('./note');

const models = {
  Note
};

module.exports = models;
